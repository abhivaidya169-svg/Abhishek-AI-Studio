# Abhishek AI Studio — Android starter

This is version 0.1.0: an Android Studio starter project with the app interface for:
- Text-to-video mode
- Image-to-video mode and image picker
- Prompt field
- 9:16, 16:9 and 1:1 aspect-ratio choices
- 5, 8 and 10 second clip choices

## Important
This is a UI prototype, not a working AI video generator yet. Real generation needs a video model and an inference backend/API. A genuinely unlimited, free, cloud Seedance-equivalent service cannot be promised. Open-source models can reduce licensing/API costs, but still need suitable GPU hardware and electricity/hosting.

## Build an APK
1. Install Android Studio on a computer.
2. Open this extracted `AbhishekAIStudio` folder.
3. Allow Gradle sync and install the required Android SDK (API 35).
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location.

## Next development step
Connect a backend endpoint for job creation, progress polling, and video download. Do not put private API keys directly inside the APK; keep them on the backend.

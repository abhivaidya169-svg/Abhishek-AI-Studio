package com.abhishek.aistudio

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface

class MainActivity : Activity() {
    private var selectedImage: Uri? = null
    private lateinit var status: TextView
    private lateinit var prompt: EditText
    private lateinit var mode: Spinner
    private lateinit var ratio: Spinner
    private lateinit var duration: Spinner

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16,16,26)
        window.navigationBarColor = Color.rgb(16,16,26)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(20))
            setBackgroundColor(Color.rgb(16,16,26))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val title = TextView(this).apply {
            text = "Abhishek AI Studio"
            textSize = 25f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        content.addView(title)
        content.addView(label("Create videos with AI • Your creative studio"))
        content.addView(space(20))

        content.addView(section("1. Choose generation mode"))
        mode = spinner(listOf("Text to Video", "Image to Video"))
        content.addView(mode)
        content.addView(space(14))

        content.addView(section("2. Describe your video"))
        prompt = EditText(this).apply {
            hint = "Example: A cinematic sunrise over the Himalayas..."
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 15f
            gravity = Gravity.TOP
            minLines = 4
            setPadding(dp(14), dp(12), dp(14), dp(12))
            setBackgroundColor(Color.rgb(37,37,54))
        }
        content.addView(prompt, LinearLayout.LayoutParams(-1, dp(125)))
        content.addView(space(14))

        val pick = button("Select image (for Image to Video)") {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "image/*"
            }
            startActivityForResult(intent, 1001)
        }
        content.addView(pick)
        content.addView(space(14))

        content.addView(section("3. Video settings"))
        content.addView(label("Aspect ratio"))
        ratio = spinner(listOf("9:16 • Shorts / Reels", "16:9 • YouTube", "1:1 • Square"))
        content.addView(ratio)
        content.addView(label("Clip duration"))
        duration = spinner(listOf("5 seconds", "8 seconds", "10 seconds"))
        content.addView(duration)
        content.addView(space(20))

        val generate = button("Generate video") {
            val chosenMode = mode.selectedItem.toString()
            if (prompt.text.toString().trim().isEmpty()) {
                status.text = "Please enter a video prompt first."
            } else if (chosenMode.startsWith("Image") && selectedImage == null) {
                status.text = "Please select an image for Image to Video."
            } else {
                status.text = "UI prototype ready. Connect an AI video engine/API to enable real generation."
            }
        }
        content.addView(generate)
        content.addView(space(16))

        status = label("Ready • AI engine connection is not configured yet.")
        status.textSize = 14f
        content.addView(status)
        content.addView(space(18))
        content.addView(label("Note: This first build is the app interface. Actual AI generation requires a compatible video model running on a server or supported device."))
        setContentView(root)
    }

    private fun section(s: String) = TextView(this).apply {
        text = s; textSize = 17f; setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(4), 0, dp(8))
    }

    private fun label(s: String) = TextView(this).apply {
        text = s; textSize = 13f; setTextColor(Color.LTGRAY)
        setPadding(0, dp(5), 0, dp(7))
    }

    private fun space(h: Int) = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun spinner(items: List<String>) = Spinner(this).apply {
        adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, items)
        setBackgroundColor(Color.rgb(37,37,54))
    }

    private fun button(textValue: String, action: () -> Unit) = Button(this).apply {
        text = textValue
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(107,70,193))
        setOnClickListener { action() }
    }

    @Deprecated("Deprecated in Android")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            selectedImage = data?.data
            selectedImage?.let {
                contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                status.text = "Image selected successfully."
            }
        }
    }
}
